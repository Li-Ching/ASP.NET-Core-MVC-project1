﻿using Microsoft.AspNetCore.Mvc;
using project1.Models;

namespace project1.Controllers
{
    public class AreaController : Controller
    {// GET: Math
        public ActionResult AreaCompute()
        {
            return View();
        }

        [HttpPost]
        // 利用Include只要自動繫結MathViewModel中的Num1及Num2
        public ActionResult AreaCompute([Bind(include: "Num1, Num2, Type")] AreaViewModel mathdata, string btnCompute)
        {
            if (!ModelState.IsValid)
            {
                return View(mathdata);
            }

            try
            {
                double num1, num2, result;
                int type;
#pragma warning disable CS8629 // 可為 Null 的實值型別可為 Null。
                num1 = (double)mathdata.Num1;
                num2 = (double)mathdata.Num2;
                type = mathdata.Type;
#pragma warning disable CS8629 // 可為 Null 的實值型別可為 Null。
                if (type == 0)
                {
                    result = num1 * num2;
                }
                else
                {
                    result = (num1 * num2) / 2;
                }


                // 將結果值四捨五入，並取到小數點2位
                result = Math.Round(result, 2);

                mathdata.Result = result.ToString();
                return View(mathdata);
            }
            catch (Exception ex)
            {
                string str = "數學運算時發生例外，原因如下：\n" + ex.Message;
                mathdata.Result = str;
                return View(mathdata);
            }
        }
    }
}
