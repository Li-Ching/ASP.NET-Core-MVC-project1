﻿using Microsoft.AspNetCore.Mvc;
using project1.Models;

namespace Project1.Controllers
{
    public class RandomController : Controller
    {
        public IActionResult RandomGen()
        {
            return View();
        }

        [HttpPost]
        // 利用Exclude不要自動繫結模型中的Result
        public ActionResult RandomGen([Bind(include: "Num1, Num2, Num3")] RandomViewModel randomdata)
        {

            if (!ModelState.IsValid)
            {
                return View(randomdata);
            }

            // delcare local variables
            int num, count, num1, num2, num3;
            bool flag;
            int[] lotteryNum = new int[100];
            string str = "隨機亂數：";
            Random rand = new Random();

#pragma warning disable CS8629 // 可為 Null 的實值型別可為 Null。
            num1 = (int)randomdata.Num1;
            num2 = (int)randomdata.Num2;
            num3 = (int)randomdata.Num3;
            if (num1 > num2)
            {
                ModelState.AddModelError("Num1", "數字1需小於數字2");
            }
            else if (num2 - num1 < num3)
            {
                ModelState.AddModelError("Num3", "想要產生的亂數需小於數字1和數字2的範圍!!");
            }
            else if (num3 > 100)
            {
                ModelState.AddModelError("Num3", "只能產生100個以內的亂數喔!");
            }
            else
            {


                count = 0;
                for (int j = 0; j < 100; j++) lotteryNum[j] = 0;
                //
                do
                {
                    num = rand.Next(num1, num2 + 1);
                    flag = Exist(lotteryNum, count, num);
                    if (flag == false)
                    {
                        lotteryNum[count] = num;
                        count++;
                    }
                } while (count < num3);
                //
                Array.Sort(lotteryNum, 0, num3);



                for (int k = 0; k < num3; k++)
                {
                    str += "\n" + String.Format("{0:d2}", lotteryNum[k]);
                }

                randomdata.Result = str;
            }
            return View(randomdata);
        }


        public bool Exist(int[] numarray, int count, int number)
        {
            bool status = false;
            for (int i = 0; i < count; i++)
            {
                if (numarray[i] == number)
                {
                    status = true;
                    break;
                }
            }
            return status;
        }
    }
}
