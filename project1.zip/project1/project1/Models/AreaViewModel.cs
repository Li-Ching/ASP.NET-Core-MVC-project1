﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace project1.Models
{
    public class AreaViewModel
    {
        [DisplayName("計算形狀：")]
        [Required(ErrorMessage = "請選擇計算形狀")]
        public int Type { get; set; }

        [DisplayName("長(底)：")]
        [Required(ErrorMessage = "請輸入長(底)")]
        public double? Num1 { get; set; }

        [DisplayName("寬(高)：")]
        [Required(ErrorMessage = "請輸入寬(高)")]
        public double? Num2 { get; set; }

        [DisplayName("結 果：")]
        public string? Result { get; set; }
    }
}