﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace project1.Models
{
    public class RandomViewModel
    {
        [DisplayName("從")]
        [Required(ErrorMessage = "請輸入數字1")]
        public int? Num1 { get; set; }

        [DisplayName("到")]
        [Required(ErrorMessage = "請輸入數字2")]
        public int? Num2 { get; set; }

        [DisplayName("選")]
        [Required(ErrorMessage = "請輸入數字3")]
        [Range(0, 100)]
        public int? Num3 { get; set; }

        [DisplayName("結果：")]
        public string? Result { get; set; }
    }
}
